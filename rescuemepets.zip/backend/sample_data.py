from sqlalchemy.orm import Session
import models

def create_sample_data(db: Session):
    try:
        if db.query(models.Center).count() > 0:
            return
    except Exception:
        return  # Tables not ready yet, skip seeding

    center1 = models.Center(
        name="Happy Tails Shelter", location="New York, NY",
        contact="contact@happytails.com", phone="+1 (212) 555-0101",
        website="https://happytails.example.com",
        opening_hours="Mon–Fri: 9am–6pm | Sat–Sun: 10am–4pm",
        map_query="Happy+Tails+Shelter+New+York+NY",
        description="Happy Tails Shelter has been rescuing animals in New York City since 2005. We are a no-kill shelter dedicated to finding loving homes for dogs, cats, and small animals. Our team of 30+ volunteers works tirelessly to rehabilitate and rehome animals in need."
    )
    center2 = models.Center(
        name="Paws Rescue", location="Los Angeles, CA",
        contact="info@pawsrescue.com", phone="+1 (310) 555-0202",
        website="https://pawsrescue.example.com",
        opening_hours="Mon–Sun: 10am–5pm",
        map_query="Paws+Rescue+Los+Angeles+CA",
        description="Paws Rescue is LA's premier animal rescue organization. Founded in 2010, we specialize in rescuing animals from high-kill shelters and providing them with medical care, socialization, and forever homes. We've successfully rehomed over 5,000 animals."
    )
    center3 = models.Center(
        name="Second Chance Animal Shelter", location="Chicago, IL",
        contact="hello@secondchance.com", phone="+1 (312) 555-0303",
        website="https://secondchance.example.com",
        opening_hours="Tue–Fri: 11am–7pm | Sat–Sun: 10am–5pm | Mon: Closed",
        map_query="Second+Chance+Animal+Shelter+Chicago+IL",
        description="Second Chance believes every animal deserves exactly that — a second chance. Based in Chicago, we rescue animals from difficult situations and provide comprehensive care including veterinary treatment, behavioral training, and loving foster homes before adoption."
    )
    center4 = models.Center(
        name="Forever Home Rescue", location="Austin, TX",
        contact="adopt@foreverhome.com", phone="+1 (512) 555-0404",
        website="https://foreverhome.example.com",
        opening_hours="Mon–Sat: 9am–7pm | Sun: 11am–4pm",
        map_query="Forever+Home+Rescue+Austin+TX",
        description="Forever Home Rescue is Austin's most trusted animal rescue. We operate a network of foster homes across the city, ensuring every animal receives personalized care in a home environment. Our adoption counselors work closely with families to find the perfect match."
    )
    db.add_all([center1, center2, center3, center4])
    db.commit()

    animals = [
        models.Animal(name="Buddy", species="Dog", breed="Golden Retriever", age=3, status="available",
            tags="friendly,playful,good with kids", energy_level="high",
            vaccinated=True, neutered=True, microchipped=True, good_with_kids=True, good_with_pets=True,
            description="Buddy is a cheerful, energetic Golden Retriever who loves fetch, swimming, and cuddles. Great with kids and other dogs. House-trained and knows basic commands.",
            image="https://images.unsplash.com/photo-1552053831-71594a27632d?w=600&q=80", center_id=center1.id),
        models.Animal(name="Max", species="Dog", breed="German Shepherd", age=4, status="available",
            tags="loyal,protective,intelligent", energy_level="high",
            vaccinated=True, neutered=False, microchipped=True, good_with_kids=True, good_with_pets=False,
            description="Max is a loyal, intelligent German Shepherd. He's protective, well-trained, and great with families. Loves long walks and learning new tricks.",
            image="https://images.unsplash.com/photo-1589941013453-ec89f33b5e95?w=600&q=80", center_id=center1.id),
        models.Animal(name="Bella", species="Dog", breed="Beagle", age=2, status="available",
            tags="curious,gentle,playful", energy_level="medium",
            vaccinated=True, neutered=True, microchipped=False, good_with_kids=True, good_with_pets=True,
            description="Bella is a sweet, curious Beagle with a great nose and an even better personality. She loves sniffing around the yard and snuggling on the couch.",
            image="https://images.unsplash.com/photo-1505628346881-b72b27e84530?w=600&q=80", center_id=center1.id),
        models.Animal(name="Charlie", species="Dog", breed="Labrador Retriever", age=1, status="available",
            tags="energetic,friendly,good with kids", energy_level="high",
            vaccinated=True, neutered=False, microchipped=True, good_with_kids=True, good_with_pets=True,
            description="Charlie is a playful, affectionate Labrador puppy. He's full of energy and loves everyone he meets. Perfect for an active family.",
            image="https://images.unsplash.com/photo-1591160690555-5debfba289f0?w=600&q=80", center_id=center2.id),
        models.Animal(name="Luna", species="Dog", breed="Siberian Husky", age=3, status="available",
            tags="energetic,outdoor,playful", energy_level="high",
            vaccinated=True, neutered=True, microchipped=True, good_with_kids=True, good_with_pets=False,
            description="Luna is a stunning Siberian Husky with piercing blue eyes. She's energetic, loves the outdoors, and is great with children. Needs an active home.",
            image="https://images.unsplash.com/photo-1605568427561-40dd23c2acea?w=600&q=80", center_id=center2.id),
        models.Animal(name="Rocky", species="Dog", breed="Bulldog", age=5, status="available",
            tags="calm,gentle,low energy", energy_level="low",
            vaccinated=True, neutered=True, microchipped=True, good_with_kids=True, good_with_pets=True,
            description="Rocky is a calm, gentle Bulldog who loves lounging around and short walks. Great with kids and very low maintenance. A true couch companion.",
            image="https://images.unsplash.com/photo-1583511655857-d19b40a7a54e?w=600&q=80", center_id=center2.id),
        models.Animal(name="Daisy", species="Dog", breed="Poodle", age=2, status="pending",
            tags="intelligent,hypoallergenic,friendly", energy_level="medium",
            vaccinated=True, neutered=True, microchipped=True, good_with_kids=True, good_with_pets=True,
            description="Daisy is an elegant, intelligent Poodle who loves to learn and show off her tricks. Hypoallergenic and great for families with allergies.",
            image="https://images.unsplash.com/photo-1587300003388-59208cc962cb?w=600&q=80", center_id=center3.id),
        models.Animal(name="Cooper", species="Dog", breed="Border Collie", age=2, status="available",
            tags="intelligent,active,loyal", energy_level="high",
            vaccinated=True, neutered=False, microchipped=True, good_with_kids=False, good_with_pets=True,
            description="Cooper is an incredibly smart Border Collie who excels at agility and loves mental challenges. Needs an active owner who can keep up with his energy.",
            image="https://images.unsplash.com/photo-1503256207526-0d5d80fa2f47?w=600&q=80", center_id=center3.id),
        models.Animal(name="Zeus", species="Dog", breed="Rottweiler", age=4, status="available",
            tags="loyal,calm,protective", energy_level="medium",
            vaccinated=True, neutered=True, microchipped=True, good_with_kids=True, good_with_pets=False,
            description="Zeus is a gentle giant Rottweiler who is incredibly loyal and loving with his family. Well-trained, calm indoors, and great with older children.",
            image="https://images.unsplash.com/photo-1567752881298-894bb81f9379?w=600&q=80", center_id=center4.id),
        models.Animal(name="Coco", species="Dog", breed="Dachshund", age=3, status="available",
            tags="playful,curious,friendly", energy_level="medium",
            vaccinated=True, neutered=True, microchipped=False, good_with_kids=True, good_with_pets=True,
            description="Coco is a feisty little Dachshund with a huge personality. She loves burrowing under blankets, playing with toys, and going on adventures.",
            image="https://images.unsplash.com/photo-1518717758536-85ae29035b6d?w=600&q=80", center_id=center4.id),
        models.Animal(name="Whiskers", species="Cat", breed="Siamese", age=2, status="available",
            tags="talkative,affectionate,social", energy_level="medium",
            vaccinated=True, neutered=True, microchipped=True, good_with_kids=True, good_with_pets=False,
            description="Whiskers is a talkative, affectionate Siamese who loves being the center of attention. She'll follow you around the house and chat all day long.",
            image="https://images.unsplash.com/photo-1555685812-4b943f1cb0eb?w=600&q=80", center_id=center1.id),
        models.Animal(name="Oliver", species="Cat", breed="Maine Coon", age=3, status="available",
            tags="gentle,fluffy,calm", energy_level="low",
            vaccinated=True, neutered=True, microchipped=True, good_with_kids=True, good_with_pets=True,
            description="Oliver is a majestic Maine Coon with a fluffy coat and gentle giant personality. He loves being brushed and will happily sit on your lap for hours.",
            image="https://images.unsplash.com/photo-1574158622682-e40e69881006?w=600&q=80", center_id=center2.id),
        models.Animal(name="Mittens", species="Cat", breed="Persian", age=4, status="adopted",
            tags="calm,regal,quiet", energy_level="low",
            vaccinated=True, neutered=True, microchipped=True, good_with_kids=False, good_with_pets=False,
            description="Mittens is a calm, regal Persian cat who loves quiet environments. She enjoys being pampered and is perfect for a relaxed household.",
            image="https://images.unsplash.com/photo-1561948955-570b270e7c36?w=600&q=80", center_id=center2.id),
        models.Animal(name="Shadow", species="Cat", breed="British Shorthair", age=2, status="available",
            tags="independent,easygoing,calm", energy_level="low",
            vaccinated=True, neutered=True, microchipped=False, good_with_kids=True, good_with_pets=True,
            description="Shadow is a cool, independent British Shorthair with a plush grey coat. He's easygoing, gets along with everyone, and loves window watching.",
            image="https://images.unsplash.com/photo-1592194996308-7b43878e84a6?w=600&q=80", center_id=center3.id),
        models.Animal(name="Cleo", species="Cat", breed="Abyssinian", age=1, status="available",
            tags="playful,athletic,curious", energy_level="high",
            vaccinated=True, neutered=False, microchipped=True, good_with_kids=True, good_with_pets=True,
            description="Cleo is a playful, athletic Abyssinian kitten who loves to climb and explore. She's curious about everything and will keep you entertained all day.",
            image="https://images.unsplash.com/photo-1543466835-00a7907e9de1?w=600&q=80", center_id=center3.id),
        models.Animal(name="Leo", species="Cat", breed="Ragdoll", age=3, status="available",
            tags="docile,gentle,good with kids", energy_level="low",
            vaccinated=True, neutered=True, microchipped=True, good_with_kids=True, good_with_pets=True,
            description="Leo is a floppy, docile Ragdoll who goes limp when you pick him up. He's incredibly gentle, loves cuddles, and is great with children.",
            image="https://images.unsplash.com/photo-1548802673-380ab8ebc7b7?w=600&q=80", center_id=center4.id),
        models.Animal(name="Nala", species="Cat", breed="Bengal", age=2, status="available",
            tags="wild,playful,active", energy_level="high",
            vaccinated=True, neutered=True, microchipped=True, good_with_kids=False, good_with_pets=False,
            description="Nala is a wild-looking Bengal cat with a heart of gold. She loves interactive play, water, and showing off her beautiful spotted coat.",
            image="https://images.unsplash.com/photo-1596854407944-bf87f6fdd49e?w=600&q=80", center_id=center4.id),
        models.Animal(name="Thumper", species="Rabbit", breed="Holland Lop", age=1, status="available",
            tags="gentle,quiet,friendly", energy_level="low",
            vaccinated=True, neutered=False, microchipped=False, good_with_kids=True, good_with_pets=True,
            description="Thumper is an adorable Holland Lop with floppy ears and a gentle nature. He loves fresh veggies, hopping around, and being gently petted.",
            image="https://images.unsplash.com/photo-1585110396000-c9ffd4e4b308?w=600&q=80", center_id=center1.id),
        models.Animal(name="Snowball", species="Rabbit", breed="Angora", age=2, status="available",
            tags="calm,fluffy,quiet", energy_level="low",
            vaccinated=True, neutered=True, microchipped=False, good_with_kids=True, good_with_pets=True,
            description="Snowball is a fluffy white Angora rabbit who looks like a cloud. She's calm, loves being groomed, and is perfect for a quiet home.",
            image="https://images.unsplash.com/photo-1452857297128-d9c29adba80b?w=600&q=80", center_id=center3.id),
        models.Animal(name="Kiwi", species="Bird", breed="Budgerigar", age=1, status="available",
            tags="social,cheerful,easy care", energy_level="medium",
            vaccinated=False, neutered=False, microchipped=False, good_with_kids=True, good_with_pets=False,
            description="Kiwi is a cheerful green budgie who loves to sing and mimic sounds. He's social, easy to care for, and will brighten up any room.",
            image="https://images.unsplash.com/photo-1552728089-57bdde30beb3?w=600&q=80", center_id=center2.id),
        models.Animal(name="Mango", species="Bird", breed="Cockatiel", age=2, status="available",
            tags="friendly,musical,hand-tamed", energy_level="medium",
            vaccinated=False, neutered=False, microchipped=False, good_with_kids=True, good_with_pets=False,
            description="Mango is a friendly cockatiel who loves whistling tunes and sitting on shoulders. He's hand-tamed and great for first-time bird owners.",
            image="https://images.unsplash.com/photo-1544923246-77307dd654cb?w=600&q=80", center_id=center4.id),
    ]
    db.add_all(animals)
    db.commit()

    stories = [
        models.RescueStory(
            center_id=center1.id, animal_name="Mittens",
            animal_image="https://images.unsplash.com/photo-1561948955-570b270e7c36?w=600&q=80",
            adopter_name="The Johnson Family",
            story="We adopted Mittens two years ago and she has completely transformed our home. She sleeps at the foot of our bed every night and greets us at the door. We can't imagine life without her.",
            adopted_on="January 2023"
        ),
        models.RescueStory(
            center_id=center1.id, animal_name="Rex",
            animal_image="https://images.unsplash.com/photo-1587300003388-59208cc962cb?w=600&q=80",
            adopter_name="Sarah & Tom",
            story="Rex was shy when we first met him but within a week he was running laps around our backyard. He's our jogging partner, our alarm clock, and our best friend. Best decision we ever made.",
            adopted_on="June 2023"
        ),
        models.RescueStory(
            center_id=center2.id, animal_name="Biscuit",
            animal_image="https://images.unsplash.com/photo-1552053831-71594a27632d?w=600&q=80",
            adopter_name="The Omondi Family",
            story="Biscuit came to us as a timid puppy. Today he's the most confident, loving dog you'll ever meet. He plays with our kids every afternoon and has brought so much joy to our family.",
            adopted_on="March 2024"
        ),
        models.RescueStory(
            center_id=center2.id, animal_name="Pearl",
            animal_image="https://images.unsplash.com/photo-1574158622682-e40e69881006?w=600&q=80",
            adopter_name="Amara N.",
            story="I was nervous about adopting my first cat but the team at Paws Rescue guided me through everything. Pearl settled in within days and now she's my work-from-home companion. She sits on my desk every single day.",
            adopted_on="August 2024"
        ),
        models.RescueStory(
            center_id=center3.id, animal_name="Duke",
            animal_image="https://images.unsplash.com/photo-1589941013453-ec89f33b5e95?w=600&q=80",
            adopter_name="The Williams Family",
            story="Duke was a Second Chance success story in every sense. He'd been passed over three times before we met him. Now he goes hiking with us every weekend and has his own Instagram. He deserved this.",
            adopted_on="November 2023"
        ),
        models.RescueStory(
            center_id=center4.id, animal_name="Cinnamon",
            animal_image="https://images.unsplash.com/photo-1543466835-00a7907e9de1?w=600&q=80",
            adopter_name="James & Priya",
            story="We adopted Cinnamon on a whim and it was the best whim of our lives. She's feisty, funny, and endlessly entertaining. Our apartment feels like a home now because of her.",
            adopted_on="February 2025"
        ),
    ]
    db.add_all(stories)
    db.commit()

    vets = [
        models.Vet(name="Dr. Sarah Kimani", clinic="PawsCare Veterinary", phone="+1 (212) 555-1001", specialization="General & Surgery", center_id=center1.id),
        models.Vet(name="Dr. James Oduya", clinic="Happy Tails Vet Clinic", phone="+1 (212) 555-1002", specialization="Exotic Animals", center_id=center1.id),
        models.Vet(name="Dr. Maria Lopez", clinic="LA Animal Health Center", phone="+1 (310) 555-2001", specialization="General Practice", center_id=center2.id),
        models.Vet(name="Dr. Kevin Mwangi", clinic="Paws & Claws Clinic", phone="+1 (310) 555-2002", specialization="Dermatology", center_id=center2.id),
        models.Vet(name="Dr. Aisha Njoroge", clinic="Second Chance Vet", phone="+1 (312) 555-3001", specialization="Internal Medicine", center_id=center3.id),
        models.Vet(name="Dr. Tom Waweru", clinic="Chicago Pet Hospital", phone="+1 (312) 555-3002", specialization="Orthopedics", center_id=center3.id),
        models.Vet(name="Dr. Grace Otieno", clinic="Austin Animal Clinic", phone="+1 (512) 555-4001", specialization="General Practice", center_id=center4.id),
        models.Vet(name="Dr. Brian Kamau", clinic="Forever Home Vet", phone="+1 (512) 555-4002", specialization="Nutrition & Wellness", center_id=center4.id),
    ]
    db.add_all(vets)
    db.commit()
