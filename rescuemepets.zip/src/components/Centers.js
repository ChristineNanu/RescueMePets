import React, { useEffect, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { API_BASE_URL } from '../constants';

const CENTER_IMAGES = [
  'https://images.unsplash.com/photo-1601758124510-52d02ddb7cbd?w=800&q=80',
  'https://images.unsplash.com/photo-1548199973-03cce0bbc87b?w=800&q=80',
  'https://images.unsplash.com/photo-1587300003388-59208cc962cb?w=800&q=80',
  'https://images.unsplash.com/photo-1544568100-847a948585b9?w=800&q=80',
];

const STATUS = {
  available: { pill: 'bg-teal-100 text-teal-700',  dot: '🟢', label: 'Available' },
  pending:   { pill: 'bg-cream-100 text-cream-700', dot: '🟡', label: 'Pending'   },
  adopted:   { pill: 'bg-coral-100 text-coral-600', dot: '🔴', label: 'Adopted'   },
};

function StoryCard({ story }) {
  return (
    <div className="bg-white rounded-3xl overflow-hidden shadow-card border border-teal-50 flex flex-col">
      <div className="relative h-44 overflow-hidden">
        <img src={story.animal_image} alt={story.animal_name}
          className="w-full h-full object-cover"
          onError={e => e.target.src = 'https://images.unsplash.com/photo-1548199973-03cce0bbc87b?w=600&q=80'} />
        <div className="absolute inset-0 bg-gradient-to-t from-teal-900/70 to-transparent" />
        <div className="absolute bottom-3 left-3">
          <span className="bg-teal-500 text-white text-xs font-bold px-2.5 py-1 rounded-full">🏠 Adopted</span>
        </div>
        <div className="absolute top-3 right-3 bg-white/90 backdrop-blur-sm rounded-full px-2.5 py-1">
          <span className="text-xs font-bold text-gray-500">{story.adopted_on}</span>
        </div>
      </div>
      <div className="p-5 flex flex-col flex-1">
        <div className="flex items-center gap-2 mb-3">
          <div className="w-8 h-8 bg-gradient-to-br from-teal-400 to-teal-600 rounded-full flex items-center justify-center text-white text-sm font-black flex-shrink-0">
            {story.adopter_name[0]}
          </div>
          <div>
            <p className="text-xs font-bold text-gray-800">{story.adopter_name}</p>
            <p className="text-xs text-teal-600">adopted {story.animal_name}</p>
          </div>
        </div>
        <p className="text-gray-500 text-sm leading-relaxed flex-1 italic">"{story.story}"</p>
        <div className="mt-3 flex gap-0.5">
          {[...Array(5)].map((_, i) => <span key={i} className="text-amber-400 text-sm">★</span>)}
        </div>
      </div>
    </div>
  );
}

function VetCard({ vet, userId }) {
  const [open, setOpen]   = useState(false);
  const [name, setName]   = useState('');
  const [email, setEmail] = useState('');
  const [msg, setMsg]     = useState('');
  const [status, setStatus] = useState('');
  const [sending, setSending] = useState(false);

  const send = async () => {
    if (!msg.trim() || !name.trim() || !email.trim()) { setStatus('Please fill all fields.'); return; }
    setSending(true);
    const res = await fetch(`${API_BASE_URL}/vets/${vet.id}/message`, {
      method: 'POST', headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ name, email, message: msg, user_id: userId ? parseInt(userId) : null }),
    });
    setSending(false);
    if (res.ok) { setStatus('✅ Message sent!'); setMsg(''); setTimeout(() => { setOpen(false); setStatus(''); }, 1800); }
    else setStatus('❌ Failed to send. Try again.');
  };

  return (
    <div style={{ animation: `fadeUp 0.5s ${vet._idx * 80}ms ease both` }}
      className="bg-white rounded-2xl shadow-card border border-teal-50 hover:-translate-y-1 hover:shadow-card-hover transition-all duration-300">
      <div className="p-5 flex items-start gap-4">
        <div className="w-12 h-12 bg-gradient-to-br from-teal-400 to-teal-600 rounded-2xl flex items-center justify-center text-white text-xl font-black flex-shrink-0 shadow-md">
          {vet.name.split(' ').pop()[0]}
        </div>
        <div className="flex-1 min-w-0">
          <p className="font-black text-gray-800 text-sm">{vet.name}</p>
          <p className="text-teal-600 text-xs font-semibold mb-2">{vet.specialization}</p>
          <p className="text-gray-400 text-xs mb-0.5 truncate">🏥 {vet.clinic}</p>
          <a href={`tel:${vet.phone}`} className="text-xs text-teal-600 font-semibold no-underline hover:underline">📞 {vet.phone}</a>
        </div>
        <button onClick={() => { setOpen(o => !o); setStatus(''); }}
          className={`flex-shrink-0 text-xs font-bold px-3 py-1.5 rounded-xl border-0 cursor-pointer transition-all
            ${open ? 'bg-gray-100 text-gray-500' : 'bg-teal-50 text-teal-700 hover:bg-teal-100'}`}>
          {open ? '✕ Close' : '✉️ Message'}
        </button>
      </div>

      {open && (
        <div className="px-5 pb-5 animate-slide-down">
          <div className="border-t border-teal-50 pt-4 space-y-2.5">
            <div className="grid grid-cols-2 gap-2">
              <input value={name} onChange={e => setName(e.target.value)}
                placeholder="Your name" className="input-field text-xs py-2" />
              <input value={email} onChange={e => setEmail(e.target.value)}
                placeholder="Your email" type="email" className="input-field text-xs py-2" />
            </div>
            <textarea value={msg} onChange={e => setMsg(e.target.value)}
              placeholder={`Message for ${vet.name}...`} rows={3}
              className="input-field text-xs py-2 resize-none w-full" />
            {status && <p className="text-xs font-semibold">{status}</p>}
            <button onClick={send} disabled={sending}
              className="w-full py-2.5 rounded-xl text-xs font-bold bg-gradient-to-r from-teal-500 to-teal-600 text-white border-0 cursor-pointer hover:shadow-lg transition-all disabled:opacity-50">
              {sending ? 'Sending...' : '📨 Send Message'}
            </button>
          </div>
        </div>
      )}
    </div>
  );
}

function Centers() {
  const [centers, setCenters]               = useState([]);
  const [selectedCenter, setSelectedCenter] = useState(null);
  const [centerAnimals, setCenterAnimals]   = useState([]);
  const [stories, setStories]               = useState([]);
  const [centerVets, setCenterVets]         = useState([]);
  const [loading, setLoading]               = useState(true);
  const [animalsLoading, setAnimalsLoading] = useState(false);
  const [galleryAnimal, setGalleryAnimal]   = useState(null);
  const navigate = useNavigate();
  const userId = localStorage.getItem('user_id');

  useEffect(() => {
    fetch(`${API_BASE_URL}/centers`)
      .then(r => r.json())
      .then(data => { setCenters(data); setLoading(false); })
      .catch(() => setLoading(false));
  }, []);

  const handleVisitCenter = (center) => {
    setSelectedCenter(center);
    setAnimalsLoading(true);
    setStories([]);
    setCenterVets([]);
    const params = userId ? `?user_id=${userId}` : '';
    fetch(`${API_BASE_URL}/animals${params}`)
      .then(r => r.json())
      .then(animals => { setCenterAnimals(animals.filter(a => a.center?.id === center.id)); setAnimalsLoading(false); });
    fetch(`${API_BASE_URL}/centers/${center.id}/stories`)
      .then(r => r.json())
      .then(setStories)
      .catch(() => {});
    fetch(`${API_BASE_URL}/vets?center_id=${center.id}`)
      .then(r => r.json())
      .then(data => setCenterVets(Array.isArray(data) ? data.filter(v => v.center_id === center.id) : []))
      .catch(() => {});
  };

  const toggleFavorite = async (e, animalId) => {
    e.stopPropagation();
    if (!userId) { navigate('/login'); return; }
    const res = await fetch(`${API_BASE_URL}/favorites`, {
      method: 'POST', headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ user_id: parseInt(userId), animal_id: animalId }),
    });
    const data = await res.json();
    setCenterAnimals(prev => prev.map(a => a.id === animalId ? { ...a, is_favorited: data.favorited } : a));
  };

  if (loading) return (
    <div className="page-bg min-h-screen">
      <div className="relative bg-gradient-to-r from-teal-600 to-teal-500 px-6 py-20 overflow-hidden">
        <div className="max-w-7xl mx-auto">
          <div className="skeleton h-4 w-24 mb-3" />
          <div className="skeleton h-12 w-64 mb-3" />
          <div className="skeleton h-4 w-80" />
        </div>
      </div>
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-10">
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          {[...Array(4)].map((_, i) => (
            <div key={i} className="bg-white rounded-3xl overflow-hidden shadow-card border border-teal-50">
              <div className="skeleton h-56 w-full" style={{ borderRadius: 0 }} />
              <div className="p-5 space-y-3">
                <div className="skeleton h-5 w-3/4" />
                <div className="skeleton h-4 w-1/2" />
                <div className="skeleton h-10 w-full mt-2" />
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );

  /* ── Center Detail View ── */
  if (selectedCenter) {
    const idx   = (selectedCenter.id - 1) % CENTER_IMAGES.length;
    const stats = [
      { label: 'Total Animals', value: centerAnimals.length,                                       icon: '🐾', bg: 'bg-teal-50',  text: 'text-teal-700'  },
      { label: 'Available',     value: centerAnimals.filter(a => a.status === 'available').length, icon: '✅', bg: 'bg-teal-50',  text: 'text-teal-700'  },
      { label: 'Pending',       value: centerAnimals.filter(a => a.status === 'pending').length,   icon: '⏳', bg: 'bg-cream-50', text: 'text-cream-700' },
      { label: 'Adopted',       value: centerAnimals.filter(a => a.status === 'adopted').length,   icon: '🏠', bg: 'bg-coral-50', text: 'text-coral-700' },
    ];

    return (
      <div className="page-bg min-h-screen">
        <div className="relative h-80 overflow-hidden">
          <img src={CENTER_IMAGES[idx]} alt={selectedCenter.name} className="w-full h-full object-cover" />
          <div className="absolute inset-0 bg-gradient-to-t from-teal-900/90 via-teal-800/50 to-teal-700/20" />
          <button onClick={() => { setSelectedCenter(null); setCenterAnimals([]); setStories([]); setGalleryAnimal(null); }}
            className="absolute top-5 left-5 flex items-center gap-2 glass text-white px-4 py-2 rounded-full font-semibold text-sm hover:bg-white/25 transition-all cursor-pointer border-0">
            ← Back
          </button>
          <div className="absolute bottom-0 left-0 right-0 p-6">
            <div className="max-w-7xl mx-auto flex items-end justify-between flex-wrap gap-4">
              <div>
                <span className="inline-block bg-teal-500 text-white text-xs font-bold px-3 py-1 rounded-full mb-3">🏥 Rescue Center</span>
                <h1 className="text-3xl sm:text-4xl font-black text-white mb-3 drop-shadow-lg">{selectedCenter.name}</h1>
                <div className="flex flex-wrap gap-3">
                  <span className="flex items-center gap-1.5 glass text-white text-sm px-3 py-1.5 rounded-full">📍 {selectedCenter.location}</span>
                  <span className="flex items-center gap-1.5 glass text-white text-sm px-3 py-1.5 rounded-full">📧 {selectedCenter.contact}</span>
                </div>
              </div>
              <button onClick={() => navigate('/adoption')}
                className="btn-coral px-6 py-3 text-sm flex-shrink-0">
                📋 Apply to Adopt
              </button>
            </div>
          </div>
        </div>

        {/* Stats row */}
        <div className="bg-white border-b border-teal-50 shadow-sm">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div className="grid grid-cols-4 divide-x divide-gray-100">
              {stats.map((s, i) => (
                <div key={i} className="py-5 px-4 text-center">
                  <div className={`w-10 h-10 ${s.bg} rounded-xl flex items-center justify-center text-xl mx-auto mb-2`}>{s.icon}</div>
                  <p className={`text-2xl font-black ${s.text}`}>{s.value}</p>
                  <p className="text-xs text-gray-400 font-medium mt-0.5">{s.label}</p>
                </div>
              ))}
            </div>
          </div>
        </div>

        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 pt-8">
          <div className="grid md:grid-cols-2 gap-6 mb-8">
            <div className="bg-white rounded-3xl p-6 shadow-card border border-teal-50">
              <h3 className="font-black text-gray-800 text-lg mb-3">About this Center</h3>
              {selectedCenter.description && <p className="text-gray-500 text-sm leading-relaxed mb-4">{selectedCenter.description}</p>}
              <div className="flex flex-col gap-2.5">
                {selectedCenter.opening_hours && (
                  <div className="flex items-start gap-3">
                    <span className="w-8 h-8 bg-teal-50 rounded-lg flex items-center justify-center text-base flex-shrink-0">⏰</span>
                    <div>
                      <p className="text-xs font-bold text-gray-400 uppercase tracking-wide">Opening Hours</p>
                      <p className="text-sm text-gray-700 font-medium">{selectedCenter.opening_hours}</p>
                    </div>
                  </div>
                )}
                {selectedCenter.contact && (
                  <div className="flex items-center gap-3">
                    <span className="w-8 h-8 bg-teal-50 rounded-lg flex items-center justify-center text-base flex-shrink-0">📧</span>
                    <div>
                      <p className="text-xs font-bold text-gray-400 uppercase tracking-wide">Email</p>
                      <a href={`mailto:${selectedCenter.contact}`} className="text-sm text-teal-600 font-semibold no-underline hover:underline">{selectedCenter.contact}</a>
                    </div>
                  </div>
                )}
              </div>
            </div>
            <div className="bg-white rounded-3xl overflow-hidden shadow-card border border-teal-50">
              <div className="px-5 pt-5 pb-3">
                <h3 className="font-black text-gray-800 text-lg mb-1">Find Us</h3>
                <p className="text-gray-400 text-sm">📍 {selectedCenter.location}</p>
              </div>
              <iframe title="map" width="100%" height="220" style={{ border: 0 }} loading="lazy" allowFullScreen
                src={`https://maps.google.com/maps?q=${encodeURIComponent(selectedCenter.map_query || selectedCenter.location)}&output=embed`} />
            </div>
          </div>
        </div>

        {/* ── Vets Section ── */}
        {centerVets.length > 0 && (
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 pb-6">
            <div className="flex items-center gap-2.5 mb-5">
              <h2 className="text-2xl font-black text-gray-800">Our Veterinary Team</h2>
              <span className="text-xs font-bold text-teal-600 bg-teal-50 border border-teal-100 px-3 py-1.5 rounded-full">
                {centerVets.length} vet{centerVets.length !== 1 ? 's' : ''}
              </span>
            </div>
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
              {centerVets.map((vet, i) => (
                <div key={vet.id} style={{ animation: `fadeUp 0.5s ${i * 80}ms ease both` }}>
                  <VetCard vet={{ ...vet, _idx: i }} userId={userId} />
                </div>
              ))}
            </div>
          </div>
        )}

        {/* ── Photo Gallery ── */}
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 pb-4">
          <div className="flex items-center justify-between mb-5">
            <div>
              <h2 className="text-2xl font-black text-gray-800">Animal Gallery</h2>
              <p className="text-gray-400 text-sm mt-0.5">Click any photo to meet them up close</p>
            </div>
            <span className="text-xs font-bold text-teal-600 bg-teal-50 border border-teal-100 px-3 py-1.5 rounded-full">
              {centerAnimals.filter(a => a.status === 'available').length} available
            </span>
          </div>

          {animalsLoading ? (
            <div className="flex items-center justify-center py-20">
              <div className="text-center">
                <div className="text-4xl mb-3 animate-bounce">🐾</div>
                <p className="text-teal-600 font-semibold">Loading animals...</p>
              </div>
            </div>
          ) : centerAnimals.length === 0 ? (
            <div className="text-center py-20 bg-white rounded-3xl shadow-card border border-teal-50">
              <div className="text-6xl mb-4">🐾</div>
              <h3 className="font-bold text-gray-700 text-lg mb-1">No animals here yet</h3>
              <p className="text-gray-400 text-sm">Check back soon — new animals are added regularly!</p>
            </div>
          ) : (
            <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-4 xl:grid-cols-5 gap-3">
              {[...centerAnimals].sort((a, b) => (b.sponsored ? 1 : 0) - (a.sponsored ? 1 : 0)).map(animal => {
                const s = STATUS[animal.status] || STATUS.available;
                return (
                  <div key={animal.id}
                    className={`relative rounded-2xl overflow-hidden cursor-pointer group shadow-card hover:shadow-card-hover hover:-translate-y-1 transition-all duration-300 ${animal.sponsored ? 'ring-2 ring-amber-300' : ''}`}
                    style={{ aspectRatio: '1' }}
                    onClick={() => setGalleryAnimal(animal)}>
                    <img src={animal.image} alt={animal.name}
                      className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-500"
                      onError={e => e.target.src = 'https://images.unsplash.com/photo-1548199973-03cce0bbc87b?w=600&q=80'} />
                    <div className="absolute inset-0 bg-gradient-to-t from-black/70 via-transparent to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-300" />
                    <div className="absolute bottom-0 left-0 right-0 p-2.5 translate-y-full group-hover:translate-y-0 transition-transform duration-300">
                      <p className="text-white font-black text-sm truncate">{animal.name}</p>
                      <p className="text-white/70 text-xs truncate">{animal.breed}</p>
                    </div>
                    <div className="absolute top-2 left-2 flex flex-col gap-1">
                      {animal.sponsored && <span className="text-xs font-black px-2 py-0.5 rounded-full bg-amber-400 text-white">⭐</span>}
                      <span className={`text-xs font-bold px-2 py-0.5 rounded-full ${s.pill}`}>{s.label}</span>
                    </div>
                    <button onClick={e => toggleFavorite(e, animal.id)}
                      className="absolute top-2 right-2 bg-white/90 rounded-full w-7 h-7 flex items-center justify-center text-sm shadow-sm hover:scale-110 transition-transform border-0 cursor-pointer">
                      {animal.is_favorited ? '❤️' : '🤍'}
                    </button>
                  </div>
                );
              })}
            </div>
          )}
        </div>

        {/* ── Gallery Lightbox Modal ── */}
        {galleryAnimal && (() => {
          const s = STATUS[galleryAnimal.status] || STATUS.available;
          return (
            <div className="fixed inset-0 z-50 flex items-center justify-center p-4"
              onClick={() => setGalleryAnimal(null)}>
              <div className="absolute inset-0 bg-black/70 backdrop-blur-sm" />
              <div className="relative bg-white rounded-3xl overflow-hidden shadow-2xl max-w-lg w-full animate-pop-in"
                onClick={e => e.stopPropagation()}>
                <div className="relative h-72 overflow-hidden">
                  <img src={galleryAnimal.image} alt={galleryAnimal.name}
                    className="w-full h-full object-cover"
                    onError={e => e.target.src = 'https://images.unsplash.com/photo-1548199973-03cce0bbc87b?w=600&q=80'} />
                  <div className="absolute inset-0 bg-gradient-to-t from-black/60 to-transparent" />
                  <button onClick={() => setGalleryAnimal(null)}
                    className="absolute top-4 right-4 bg-white/90 rounded-full w-9 h-9 flex items-center justify-center text-gray-700 font-bold text-lg hover:bg-white transition-all border-0 cursor-pointer shadow-md">✕</button>
                  <div className={`absolute top-4 left-4 text-xs font-bold px-2.5 py-1 rounded-full ${s.pill}`}>{s.dot} {s.label}</div>
                  <div className="absolute bottom-4 left-4">
                    <h3 className="text-2xl font-black text-white drop-shadow">{galleryAnimal.name}</h3>
                    <p className="text-white/80 text-sm">{galleryAnimal.breed} · {galleryAnimal.age} yr{galleryAnimal.age !== 1 ? 's' : ''}</p>
                  </div>
                </div>
                <div className="p-5">
                  <div className="flex flex-wrap gap-2 mb-3">
                    {galleryAnimal.vaccinated    && <span className="badge bg-teal-50 text-teal-700 border border-teal-100">💉 Vaccinated</span>}
                    {galleryAnimal.neutered      && <span className="badge bg-teal-50 text-teal-700 border border-teal-100">✂️ Neutered</span>}
                    {galleryAnimal.microchipped  && <span className="badge bg-teal-50 text-teal-700 border border-teal-100">📡 Microchipped</span>}
                    {galleryAnimal.good_with_kids && <span className="badge bg-cream-50 text-cream-700 border border-cream-100">👶 Good with kids</span>}
                    {galleryAnimal.good_with_pets && <span className="badge bg-cream-50 text-cream-700 border border-cream-100">🐾 Good with pets</span>}
                  </div>
                  <p className="text-gray-500 text-sm leading-relaxed mb-4">{galleryAnimal.description}</p>
                  <div className="flex gap-3">
                    <button onClick={() => setGalleryAnimal(null)}
                      className="flex-1 py-2.5 rounded-xl text-sm font-bold border border-gray-200 text-gray-500 hover:bg-gray-50 transition-all cursor-pointer bg-white">
                      Close
                    </button>
                    <button
                      onClick={() => { setGalleryAnimal(null); navigate(`/adoption?animalId=${galleryAnimal.id}`); }}
                      disabled={galleryAnimal.status === 'adopted'}
                      className={`flex-1 py-2.5 rounded-xl text-sm font-bold transition-all border-0
                        ${galleryAnimal.status === 'adopted'
                          ? 'bg-gray-100 text-gray-400 cursor-not-allowed'
                          : 'btn-coral cursor-pointer'}`}>
                      {galleryAnimal.status === 'adopted' ? '🏠 Adopted' : '🐾 Apply to Adopt'}
                    </button>
                  </div>
                </div>
              </div>
            </div>
          );
        })()}

        {/* ── Happy Tails Stories ── */}
        {stories.length > 0 && (
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-10">
            <div className="bg-gradient-to-r from-teal-600 to-teal-500 rounded-3xl px-8 pt-8 pb-2 mb-8 relative overflow-hidden">
              <div className="absolute inset-0 opacity-[0.06]"
                style={{ backgroundImage: 'radial-gradient(circle, white 1.5px, transparent 1.5px)', backgroundSize: '28px 28px' }} />
              <div className="relative z-10">
                <p className="section-label text-teal-200 mb-1">Happy Tails</p>
                <h2 className="text-2xl font-black text-white mb-1">Success Stories 🐾</h2>
                <p className="text-teal-100 text-sm pb-6">Animals from this center who found their forever homes.</p>
              </div>
            </div>
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
              {stories.map(story => <StoryCard key={story.id} story={story} />)}
            </div>
          </div>
        )}
      </div>
    );
  }

  /* ── Centers List View ── */
  const totalAvailable = centers.reduce((sum, c) => sum + c.animal_count, 0);

  return (
    <div className="page-bg min-h-screen">
      <div className="relative bg-gradient-to-r from-teal-600 to-teal-500 px-6 py-20 overflow-hidden">
        <div className="absolute inset-0 opacity-[0.06]"
          style={{ backgroundImage: 'radial-gradient(circle, white 1.5px, transparent 1.5px)', backgroundSize: '28px 28px' }} />
        <div className="absolute top-0 right-0 w-64 h-64 bg-white/5 rounded-full blur-3xl pointer-events-none" />
        <div className="max-w-7xl mx-auto relative z-10">
          <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-6">
            <div>
              <p className="section-label text-teal-200 mb-3">Our Network</p>
              <h1 className="text-4xl sm:text-5xl font-black text-white mb-3">Rescue Centers</h1>
              <p className="text-teal-100 text-lg max-w-lg">
                {centers.length} partner centers with {totalAvailable} animals ready to find their forever home.
              </p>
            </div>
            <div className="flex gap-3 flex-wrap sm:flex-col">
              <div className="glass rounded-2xl px-5 py-3 text-center">
                <p className="text-3xl font-black text-white">{centers.length}</p>
                <p className="text-teal-100 text-xs font-medium">Centers</p>
              </div>
              <div className="glass rounded-2xl px-5 py-3 text-center">
                <p className="text-3xl font-black text-white">{totalAvailable}</p>
                <p className="text-teal-100 text-xs font-medium">Available</p>
              </div>
            </div>
          </div>
        </div>
      </div>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-10">
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          {centers.map((center, idx) => (
            <div key={center.id}
              style={{ animation: `fadeUp 0.5s ${idx * 80}ms ease both` }}
              className="bg-white rounded-3xl overflow-hidden shadow-card border border-teal-50 hover:shadow-card-hover hover:-translate-y-2 transition-all duration-300 cursor-pointer group"
              onClick={() => handleVisitCenter(center)}>
              <div className="relative h-56 overflow-hidden">
                <img src={CENTER_IMAGES[idx % CENTER_IMAGES.length]} alt={center.name}
                  className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-700" />
                <div className="absolute inset-0 bg-gradient-to-t from-teal-900/75 via-teal-900/20 to-transparent" />
                <div className="absolute top-4 left-4">
                  <span className="bg-teal-500 text-white text-xs font-bold px-3 py-1.5 rounded-full shadow-lg">🏥 Rescue Center</span>
                </div>
                <div className="absolute top-4 right-4 bg-white/95 backdrop-blur-sm rounded-full px-3 py-1.5 flex items-center gap-1.5 shadow-md">
                  <span className="w-2 h-2 bg-teal-500 rounded-full animate-pulse" />
                  <span className="text-xs font-bold text-gray-700">{center.animal_count} available</span>
                </div>
                <div className="absolute bottom-4 left-4 right-4">
                  <h3 className="text-2xl font-black text-white drop-shadow-lg">{center.name}</h3>
                </div>
              </div>
              <div className="p-5">
                <div className="flex flex-col gap-2 mb-4">
                  <div className="flex items-center gap-2.5">
                    <div className="w-7 h-7 bg-teal-50 text-teal-600 rounded-lg flex items-center justify-center text-sm flex-shrink-0">📍</div>
                    <span className="text-gray-600 text-sm">{center.location}</span>
                  </div>
                  <div className="flex items-center gap-2.5">
                    <div className="w-7 h-7 bg-teal-50 text-teal-600 rounded-lg flex items-center justify-center text-sm flex-shrink-0">📧</div>
                    <span className="text-gray-600 text-sm">{center.contact}</span>
                  </div>
                </div>
                <div className="bg-teal-50 border border-teal-100 rounded-2xl px-4 py-3 mb-4 flex items-center justify-between">
                  <span className="text-sm font-semibold text-teal-700">🐾 {center.animal_count} animals available</span>
                  <span className="text-xs font-bold text-teal-500">→</span>
                </div>
                <button
                  className="w-full py-3 rounded-2xl font-bold text-sm bg-gradient-to-r from-teal-500 to-teal-600 text-white hover:shadow-lg transition-all border-0 cursor-pointer"
                  onClick={e => { e.stopPropagation(); handleVisitCenter(center); }}>
                  Visit Center →
                </button>
              </div>
            </div>
          ))}
        </div>

        <div className="mt-10 bg-gradient-to-r from-teal-600 to-teal-500 rounded-3xl p-8 flex flex-col sm:flex-row items-center justify-between gap-6 relative overflow-hidden">
          <div className="absolute inset-0 opacity-[0.06]"
            style={{ backgroundImage: 'radial-gradient(circle, white 1.5px, transparent 1.5px)', backgroundSize: '28px 28px' }} />
          <div className="relative z-10">
            <h3 className="text-2xl font-black text-white mb-1">Can't decide which center?</h3>
            <p className="text-teal-100 text-sm">Browse all available animals across every center in one place.</p>
          </div>
          <button onClick={() => navigate('/animals')}
            className="relative z-10 bg-white text-teal-700 font-bold px-7 py-3 rounded-2xl text-sm hover:shadow-xl transition-all border-0 cursor-pointer flex-shrink-0">
            🐾 Browse All Animals
          </button>
        </div>
      </div>
    </div>
  );
}

export default Centers;
